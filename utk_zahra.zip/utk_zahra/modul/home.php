<?php
$sql = "SELECT gambar FROM tb_caro";
$stmt = $conn->prepare($sql);
$stmt->execute();

$carouselItems = '';
$isFirstItem = true;

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $activeClass = $isFirstItem ? 'active' : '';
    $carouselItems .= '
    <div class="carousel-item ' . $activeClass . '">
        <img src="gbrproject/' . htmlspecialchars($row['gambar']) . '" class="d-block w-100" alt="Slider Image">
    </div>';
    $isFirstItem = false;
}
$conn = null;
?>
<div id="newsCarousel" class="carousel slide" data-bs-ride="carousel"> 
    <div class="carousel-inner">
        <?php echo $carouselItems; ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#newsCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#newsCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>


<div class="container py-5">
    <div class="row align-items-center">
      <!-- Kolom Kiri: Gambar -->
      <div class="col-md-6 mb-4 mb-md-0">
        <img src="asset/img/4.jpg" class="img-fluid rounded">
      </div>

      <!-- Kolom Kanan: Teks -->
      <div class="col-md-6">
        <h2 class="highlight-title">DONAT LEMBUT KAMI</h2>
        <p>
          Rahasia donat kami tidak hanya terletak pada adonan, tetapi juga pada bahan-bahan berkualitas 
          terbaik yang "berbicara" sendiri. Cokelat hitam yang kaya, kacang almond Australia yang renyah, 
          keju krim lembut dari Selandia Baru, dan matcha Jepang premium hanyalah beberapa contoh. 
          Kami tidak melakukan jalan pintas. Bahan-bahan asli lebih lezat.
        </p>
      
      </div>
    </div>
  </div>

  <div class="container text-center py-5">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <p class="fs-4 mb-4">
      Bagaimana suasana hati Anda? Kami punya donat buatan tangan yang istimewa, kopi Arabika premium, dan suguhan lezat lainnya yang disiapkan khusus untuk Anda.
      </p>
      <a href="?page=product" class="btn btn-outline-warning text-uppercase px-4 py-2">
          JELAJAHI MENU KAMI
      </a>
    </div>
  </div>
</div>

<div class="container text-center">
  <div class="row align-items-center">
  <div class="col-md-4">
      <p>Kami terus berupaya untuk mendapatkan bahan-bahan terbaik dari seluruh dunia. Kami sangat antusias untuk berbagi kombinasi rasa yang tak terbatas yang dikenal dan disukai pelanggan kami.</p>
    </div>
    <div class="col-md-4">
      <img src="asset/img/5.jpg" style="width: 300px;">
    </div>
    
    <div class="col-md-4">
      <img src="asset/img/6.jpg" style="width: 300px;">
    </div>

  </div>
</div>

