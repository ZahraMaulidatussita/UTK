<?php
    include "lib/koneksi.php";
    session_start()
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="asset/css/frontend.css">
    <title>home</title>
</head>
<body>
    <?php
    include"modul/navbar.php";
    ?>

<?php
    $page = isset($_GET['page'])?$_GET['page']:"";
    switch ($page) {
        case 'home':
            include "modul/home.php";
            break;

        case 'product':
            include "modul/product.php";
            break;   
                
        case 'contact':
            include "modul/contact.php";
            break; 
        
            case 'proses':
                include "modul/proses_pesanan.php";
                break; 

                case 'berhasil':
                  include "modul/pesanan_berhasil.php";
                  break;
                  
                  case 'login':
                    include "modul/proses_loser.php";
                    break;

                    case 'progis':
                      include "modul/proses_regis.php";
                      break ;

                      case 'logout':
                        include "modul/logout_user.php";
                        break ;

                      
        default:
            include "modul/home.php";
            break;
    }
?>

<footer class="text-white py-4 mt-5" style="background-color: #8b4513;">
  <div class="container">
    <div class="row">
      <!-- Brand / Logo -->
      <div class="col-md-4 mb-3">
        <h5 class="fw-bold">J.CO Donuts</h5>
        <p class="mb-0">Donat buatan tangan dengan cinta.</p>
      </div>

      <!-- Navigation -->
      <div class="col-md-4 mb-3">
        <h5 class="fw-bold">Menu</h5>
        <ul class="list-unstyled">
          <li><a href="?page=home" class="text-white text-decoration-none">Home</a></li>
          <li><a href="?page=product" class="text-white text-decoration-none">Products</a></li>
          <li><a href="?page=contact" class="text-white text-decoration-none">Contact Us</a></li>
        </ul>
      </div>

      <!-- Contact Info -->
      <div class="col-md-4 mb-3">
        <h5 class="fw-bold">Contact</h5>
        <p class="mb-1">Email: info@jcodonuts.com</p>
        <p class="mb-0">Phone: +62 21 1234 5678</p>
      </div>
    </div>

    <hr class="border-light">

    <div class="text-center">
      <small>© 2025 J.CO Donuts. All rights reserved.</small>
    </div>
  </div>
</footer>


<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>