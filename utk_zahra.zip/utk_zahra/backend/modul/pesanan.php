<?php
include "../lib/koneksi.php";
?>

<div class="container mt-5">
  <h2 class="text-center mb-4 text-uppercase">Daftar Pesanan</h2>
  <div class="table-responsive">
    <table class="table table-bordered table-hover">
      <thead class="table text-center align-middle">
        <tr>
          <th>No</th>
          <th>Nama Penerima</th> 
          <th>Email</th>
          <th>Alamat</th>
          <th>Metode Pembayaran</th>
          <th>Nama Produk</th>
          <th>Total</th>
          <th>Tanggal</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $no = 1;
        $stmt = $conn->prepare("SELECT * FROM tb_checkout ORDER BY id_checkout DESC");
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data as $row) :
        ?>
          <tr>
            <td class="text-center"><?= $no++; ?></td>
            <td><?= htmlspecialchars($row['nama_penerima']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['alamat']) ?></td>
            <td class="text-capitalize"><?= $row['metode_pembayaran'] ?></td>
            <td><?= htmlspecialchars($row['nama_produk']) ?></td>
            <td>Rp <?= number_format($row['harga']) ?></td>
            <td><?= date("d-m-Y H:i", strtotime($row['tanggal_checkout'])) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>  
    </table>
  </div>
</div>
