<?php
    include "../lib/koneksi.php"
?>

<div class="container mt-5">
  <h2 class="text-center mb-4 text-uppercase">Daftar Feedback</h2>
  <div class="table-responsive">
    <table class="table table-bordered table-hover">
      <thead class="table text-center">
        <tr>
          <th>Id</th>
          <th>Name</th>
          <th>Email</th>
          <th>Message</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $no = 1;
        $stmt = $conn->prepare("SELECT * FROM tb_feedback");
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data as $row) :
        ?>
          <tr>
            <td class="text-center"><?= $no++; ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['message']) ?></td>
            
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
