 <!-- Sidebar -->
 <div class="sidebar">
    <h4>Admin Dashboard</h4>
    <a href="?page=cont" class="active"><i class="fas fa-home"></i> Dashboard</a>
    <a href="?page=caro"><i class="fas fa-images"></i> Carousel</a>
    <a href="?page=datapro"><i class="fas fa-box"></i> Product</a>
    <a href="?page=pesan"><i class="fas fa-newspaper"></i> Pesanan</a>
    <a href="?page=feedback"><i class="fas fa-solid fa-comments"></i> Feedback Pelanggan</a>
    <a href="?page=logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>