<div class="mt-4">
      <h2 class="mb-4">Tambah Data Carousel</h2>
<form action="" method="POST" enctype="multipart/form-data">
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Gambar</label>
  <input type="file" name="gbr" class="form-control">
</div>
<div class="mb-3">
    <button type="submit" class="btn btn-success" name="btn">Input Data</button>
</div>
</form>
<?php
if(isset($_POST['btn'])){
    $path = '../gbrproject/';
    $gbr = $_FILES['gbr']['name'];
    move_uploaded_file($_FILES['gbr']['tmp_name'],$path.$gbr);
    $sqlinput = $conn->prepare('INSERT INTO tb_caro(gambar)VALUES(:img)');
    $sqlinput->bindParam(':img', $gbr);
    if($sqlinput->execute()){
      header('location:?page=caro');
    }else {
      echo "Gagal menambahkan data :" . $sqlinput->errorInfo()[2];
        }
      }
?>
</div>