<?php
    $id = $_GET['idcaro'];
    $b = $conn->prepare("DELETE FROM tb_caro WHERE id_caro = '$id'");
    if($b->execute()){
        header('location:?page=caro');
    }
?>