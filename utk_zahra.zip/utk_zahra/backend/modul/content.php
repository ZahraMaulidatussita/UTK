<?php
    include "../lib/koneksi.php";

    // Ambil total order
$stmtOrder = $conn->query("SELECT COUNT(*) AS total_order FROM tb_checkout");
$order = $stmtOrder->fetch(PDO::FETCH_ASSOC)['total_order'];

// Ambil total produk
$stmtProduk = $conn->query("SELECT COUNT(*) AS total_produk FROM tb_product");
$produk = $stmtProduk->fetch(PDO::FETCH_ASSOC)['total_produk'];

// Ambil total user/pelanggan
$stmtUser = $conn->query("SELECT COUNT(*) AS total_user FROM tb_user");
$user = $stmtUser->fetch(PDO::FETCH_ASSOC)['total_user'];
?>

<div class="container">
  <div class="row g-3">
    <!-- Order Quantity -->
    <div class="col-md-4">
      <div class="card p-3">
        <div class="card-body">
          <div>
            <h4><?= $order ?></h4>
            <p class="text-muted mb-0">Order Quantity</p>
          </div>
          <div class="text-primary card-icon">
            <i class="fas fa-shopping-cart"></i>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Products -->
    <div class="col-md-4">
      <div class="card p-3">
        <div class="card-body">
          <div>
            <h4><?= $produk ?></h4>
            <p class="text-muted mb-0">Products</p>
          </div>
          <div class="text-success card-icon">
            <i class="fas fa-shopping-bag"></i>
          </div>
        </div>
      </div>
    </div>

    <!-- Customers -->
    <div class="col-md-4">
      <div class="card p-3">
        <div class="card-body">
          <div>
            <h4><?= $user ?></h4>
            <p class="text-muted mb-0">Customers</p>
          </div>
          <div class="text-warning card-icon">
            <i class="fas fa-user"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
.card-icon {
      font-size: 24px;
    }
    .card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
    }
    .card-body {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .text-muted {
      font-size: 14px;
    }
  </style>