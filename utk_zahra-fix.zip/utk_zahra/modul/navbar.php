<!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-white border-bottom fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">
            <img src="asset/img/logo.png" alt="Avatar Logo" style="width:50px;" class="rounded-pill"> 
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse d-flex justify-content-between w-100" id="navbarNav">
            <!-- Menu Tengah -->
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="?page=home">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?page=product">Product</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?page=contact">Contact Us</a>
                </li>
            </ul>

            <!-- Menu Kanan (Profil dan Logout) -->
            <ul class="navbar-nav">
                <?php if (isset($_SESSION['user'])): ?>
                    <!-- Ikon profil + nama user -->
                    <li class="nav-item">
                        <a class="nav-link" href="?page=profil" title="Profil">
                            <i class="fas fa-user-circle fa-lg"></i> 
                            <?= htmlspecialchars($_SESSION['user']['nama_user']) ?>
                        </a>
                    </li>
                    <!-- Ikon logout -->
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="?page=logout" title="Logout">
                            <i class="fas fa-right-from-bracket fa-lg"></i>
                        </a>
                    </li>
                <?php else: ?>
                    <!-- Tombol login kalau belum login -->
                    <li class="nav-item">
                        <button class="btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#loginModal">Sign In</button>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

    <!-- Modal Login -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form class="modal-content" method="POST" action="modul/proses_loser.php">
      <div class="modal-header">
        <h5 class="modal-title">Sign in</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label>Email</label>
          <input type="email" name="email" class="form-control" required>
        </div>
        <div class="mb-3">
          <label>Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <p class="mt-2 text-center">
            Belum punya akun? <a href="#" data-bs-toggle="modal" data-bs-target="#registerModal" data-bs-dismiss="modal">Daftar di sini</a>
        </p>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-warning">Sign in</button>
      </div>
    </form>
  </div>
</div>


<!-- Modal Register -->
<div class="modal fade" id="registerModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form class="modal-content" method="POST" action="modul/proses_regis.php">
      <div class="modal-header"> 
        <h5 class="modal-title">Register</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label>Nama</label>
          <input type="text" name="nama" class="form-control" required>
        </div>
        <div class="mb-3">
          <label>Email</label>
          <input type="email" name="email" class="form-control" required>
        </div>
        <div class="mb-3">
          <label>Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-warning">Register</button>
      </div>
    </form>
  </div>
</div>


<?php if (isset($_GET['login']) && $_GET['login'] == 'true'): ?>
<script>
    var loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
    loginModal.show();
</script>
<?php endif; ?>
