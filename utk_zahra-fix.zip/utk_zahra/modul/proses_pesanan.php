<?php
include '/lib/koneksi.php';

if (!isset($_SESSION['user'])) {
    $_SESSION['show_login_modal'] = true;
    header("Location: ?page=home");
    echo "<script>window.location.href='index.php?page=home&login=true';</script>";
    exit;
}

// Ambil data dari form
$nama        = $_POST['nama'];
$email       = $_POST['email'];
$alamat      = $_POST['alamat'];
$pembayaran  = $_POST['pembayaran'];
$namaProduk  = $_POST['nama_produk'];
$harga       = $_POST['harga'];

// Siapkan query
try {
    $stmt = $conn->prepare("INSERT INTO tb_checkout 
        (nama_penerima, email, alamat, metode_pembayaran, nama_produk, harga) 
        VALUES (:nama, :email, :alamat, :pembayaran, :nama_produk, :harga)");

    // Bind parameter   
    $stmt->bindParam(':nama', $nama);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':alamat', $alamat);
    $stmt->bindParam(':pembayaran', $pembayaran);
    $stmt->bindParam(':nama_produk', $namaProduk);
    $stmt->bindParam(':harga', $harga);

    // Eksekusi
    $stmt->execute();

    // Sukses
    echo "<script>window.location.href='?page=berhasil';</script>";

} catch (PDOException $e) {
    echo "Gagal checkout: " . $e->getMessage();
}
?>
