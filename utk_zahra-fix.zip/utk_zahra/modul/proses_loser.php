<?php
session_start();
include '../lib/koneksi.php'; // atau sesuaikan path-nya

$email = $_POST['email'];
$password = $_POST['password'];

// Ambil data user dari database
$stmt = $conn->prepare("SELECT * FROM tb_user WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && $password === $user['password']) {
    // Simpan data user ke session
    $_SESSION['user'] = [
        'id_user' => $user['id_user'],
        'nama_user' => $user['nama_user'],
        'email' => $user['email']
    ];
    echo "<script>location.href='../index.php';</script>";
} else {
    echo "<script>alert('Email atau password salah!'); history.back();</script>";
}
?>