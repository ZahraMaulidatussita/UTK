<?php 
  include "lib/koneksi.php"; 
?>

<div class="container mt-5">
  <h2 class="text-center mb-4 text-uppercase fw-bold" style="color: #8b4513;">OUR PRODUCT</h2>
  <div class="row g-4">

  <?php
    $stmt = $conn->query("SELECT * FROM tb_product"); // Ganti dengan nama tabel kamu
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)):
  ?>  

    <!-- Card 1 -->
    <div class="col-md-4 mt-5">
      <div class="card shadow-sm h-100 card-hover">
        <img src="gbrproject/<?= htmlspecialchars($row['gambar']) ?>" class="card-img-top" alt="<?= htmlspecialchars($row['nama_product'])?>">
        <div class="card-body d-flex flex-column">
          <h5 class="card-title"><?= htmlspecialchars($row['nama_product']) ?></h5>
          <p class="card-text"><?= htmlspecialchars($row['deskripsi']) ?></p>
          <p class="card-text fw-bold">Rp <?= number_format($row['harga'], 0, ',', '.')?></p>
          <button class="btn w-100 mt-auto text-white" style="background-color: #f7a400;" data-bs-toggle="modal" data-bs-target="#checkoutModal" 
                  data-product-image="gbrproject/<?= htmlspecialchars($row['gambar']) ?>" 
                  data-product-name="<?= htmlspecialchars($row['nama_product']) ?>" 
                  data-product-price="Rp <?= number_format($row['harga']) ?>">Buy Now</button>
        </div>
      </div>
    </div>

  <?php endwhile; ?>

</div>

<style>
.card-hover {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card-hover:hover {
  transform: translateY(-5px) scale(1.02);
  box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
  z-index: 2;
}

</style>

<!-- Modal Checkout -->
<div class="modal fade" id="checkoutModal" tabindex="-1" aria-labelledby="checkoutModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="formCheckout" action="?page=proses" method="POST">
        <div class="modal-header">
          <h5 class="modal-title" id="checkoutModalLabel">Checkout Pesanan</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row">
            <!-- Kolom kiri -->
            <div class="col-md-6">
              <div class="mb-3">
                <label for="nama" class="form-label">Nama Penerima</label>
                <input type="text" name="nama" id="nama" class="form-control" required>
              </div>
              <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" id="email" class="form-control" required>
              </div>
              <div class="mb-3">
                <label for="alamat" class="form-label">Alamat Pengiriman</label>
                <textarea name="alamat" id="alamat" class="form-control" required></textarea>
              </div>
              <div class="mb-3">
                <label for="pembayaran" class="form-label">Metode Pembayaran</label>
                <select name="pembayaran" id="pembayaran" class="form-select" required>
                  <option value="">Pilih metode</option>
                  <option value="transfer">Transfer Bank</option>
                  <option value="cod">COD (Bayar di Tempat)</option>
                  <option value="ewallet">E-Wallet</option>
                </select>
              </div>

              <!-- Hidden inputs untuk produk -->
              <input type="hidden" name="nama_produk" id="modalProductName">
              <input type="hidden" name="harga" id="modalProductHarga">
              <input type="hidden" name="gambar" id="modalProductGambar">
            </div>

            <!-- Kolom kanan: Gambar -->
            <div class="col-md-6 text-center">
              <img src="" id="modalProductImage" class="img-fluid" style="max-width: 100%;">
              <p id="modalProductPrice" class="mt-3 fw-bold fs-5"></p>
            </div>
          </div>
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-warning">Checkout</button>
        </div>
      </form>
    </div>
  </div>
</div>
    </div>


<script>
  document.getElementById('checkoutModal').addEventListener('show.bs.modal', function (event) {
    var button = event.relatedTarget;
    var image = button.getAttribute('data-product-image');
    var name = button.getAttribute('data-product-name');
    var priceText = button.getAttribute('data-product-price');
    var priceClean = priceText.replace(/[^\d]/g, ''); // Hapus Rp dan titik

    // Gambar dan teks
    document.getElementById('modalProductImage').src = image;
    document.getElementById('modalProductPrice').textContent = priceText;

    // Hidden input
    document.getElementById('modalProductName').value = name;
    document.getElementById('modalProductHarga').value = priceClean;
    document.getElementById('modalProductGambar').value = image;
  });
</script>
