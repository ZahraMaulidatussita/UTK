<?php
// Memasukkan koneksi database dari file koneksi.php
include 'lib/koneksi.php';  // Pastikan jalur file sesuai dengan lokasi koneksi.php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data dari form
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Query untuk menyimpan data ke database
    $sql = "INSERT INTO tb_feedback (name, email, message) VALUES (:name, :email, :message)";

    try {
        // Menyiapkan statement
        $stmt = $conn->prepare($sql);
        // Bind parameter ke variabel
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':message', $message);

        // Eksekusi query untuk menyimpan data
        $stmt->execute();

        // Pesan sukses jika berhasil
        echo "Pesan berhasil dikirim!";
    } catch (PDOException $e) {
        // Pesan error jika gagal
        echo "Gagal mengirim pesan: " . $e->getMessage();
    }
}
?>

<section class="py-5 bg-white">
  <div class="container">
    <h2 class="text-center mb-4 text-uppercase fw-bold" style="color: #8b4513;">Contact Us</h2>
    
    <div class="row justify-content-center">
      <div class="col-md-8">
        <form method="POST" action="">
          <div class="mb-3">
            <label for="name" class="form-label">Your Name</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name" required>
          </div>

          <div class="mb-3">
            <label for="email" class="form-label">Your Email</label>
            <input type="email" class="form-control" id="email"  name="email" placeholder="Enter your email" required>
          </div>

          <div class="mb-3">
            <label for="message" class="form-label">Your Message</label>
            <textarea class="form-control" id="message" rows="5" name="message" placeholder="Type your message here..." required></textarea>
          </div>

          <div class="d-grid">
            <button type="submit" class="btn" style="background-color: #f7941d; color: white;">
              Send Message
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>

