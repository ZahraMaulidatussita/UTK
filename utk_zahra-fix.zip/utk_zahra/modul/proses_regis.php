<?php
include '../lib/koneksi.php';

$nama = $_POST['nama'];
$email = $_POST['email'];
$password = $_POST['password'];

// Cek apakah email sudah terdaftar
$cek = $conn->prepare("SELECT * FROM tb_user WHERE email = ?");
$cek->execute([$email]);

if ($cek->rowCount() > 0) {
  echo "<script>alert('Email sudah digunakan!'); window.location.href='../index.php';</script>";
} else {
  $query = $conn->prepare("INSERT INTO tb_user (nama_user, email, password) VALUES (?, ?, ?)");
  $query->execute([$nama, $email, $password]);

  echo "<script> window.location.href='../index.php?login=true';</script>";
}
?>