<?php
$sql = "SELECT gambar FROM tb_caro";
$stmt = $conn->prepare($sql);
$stmt->execute();

$carouselItems = '';
$isFirstItem = true;

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $activeClass = $isFirstItem ? 'active' : '';
    $carouselItems .= '
    <div class="carousel-item ' . $activeClass . '">
        <img src="gbrproject/' . htmlspecialchars($row['gambar']) . '" class="d-block w-100" alt="Slider Image">
    </div>';
    $isFirstItem = false;
}
$conn = null;
?>
<div id="newsCarousel" class="carousel slide" data-bs-ride="carousel"> 
    <div class="carousel-inner">
        <?php echo $carouselItems; ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#newsCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#newsCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>

<div class="container py-5">
    <div class="row align-items-center">
      <!-- Kolom Kiri: Gambar -->
      <div class="col-md-6 mb-4 mb-md-0">
        <img src="asset/img/4.jpg" class="img-fluid rounded">
      </div>

      <!-- Kolom Kanan: Teks -->
      <div class="col-md-6">
        <h2 class="highlight-title">OUR FLUFFY DONUTS</h2>
        <p>
          The secret to our donuts isn’t just in our dough, but in the finest quality ingredients
          that “speak” for themselves. Rich and dark chocolate, crunchy and crisp Australian almonds,
          New Zealand smooth cream cheese, and premium Japanese matcha just to name a few.
          We don’t do shortcuts. Real ingredients are more delicious.
        </p>
      
      </div>
    </div>
  </div>

  <div class="container text-center py-5">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <p class="fs-4 mb-4">
        What’s your mood? We’ve got exceptionally handcrafted donuts, premium sourced Arabica coffee, and other crave-inducing treats prepared just for you.
      </p>
      <a href="?page=product" class="btn btn-outline-warning text-uppercase px-4 py-2">
        Explore Our Menu
      </a>
    </div>
  </div>
</div>

<div class="container text-center">
  <div class="row align-items-center">
  <div class="col-md-4">
      <p>We are on a never-ending journey to source the best ingredients from around the world. It excites us to share endless flavor combinations that our customers come to know and love.</p>
    </div>
    <div class="col-md-4">
      <img src="asset/img/5.jpg" style="width: 300px;">
    </div>
    
    <div class="col-md-4">
      <img src="asset/img/6.jpg" style="width: 300px;">
    </div>

  </div>
</div>

