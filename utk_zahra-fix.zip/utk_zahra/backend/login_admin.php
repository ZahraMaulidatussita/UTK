 <?php
session_start();
include "../lib/koneksi.php";

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Gunakan prepared statement untuk keamanan
    $stmt = $conn->prepare("SELECT * FROM tb_admin WHERE username = :username AND password = :password");
    $stmt->execute([
        'username' => $username,
        'password' => $password
    ]);

   $user = $stmt->fetch(PDO::FETCH_ASSOC);

   if ($user) {
    $_SESSION['admin'] = $username;
    header("location: index.php");
    exit;
   } else {
    $error = "Username atau Password salah";
   }
}

?>


<style>
    .main{
        height: 100vh;
    }
    .login-box{
        width: 500px;
        height: 300px;
        box-sizing: border-box;
        border-radius: 10px;
    }
</style>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<div class="main d-flex flex-column justify-content-center align-items-center">
        <div class="login-box p-5 shadow">
            <form action="" method="post">
                <div>
                    <label for="username">Username</label>
                    <input type="text" class="form-control" name="username" id="username">
                </div>

                <div>
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password" id="password">
                </div>

                <div>
                    <button class="btn btn-warning form-control mt-3" type="submit" name="login">Login</button>
                </div>
            </form>
        </div>
</div>