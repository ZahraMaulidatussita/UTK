<div class="mt-4">
    <h2 class="mb-4">Edit Carousel</h2>
</div>

<?php
    $id = $_GET['idcaro'];
    $b = $conn->prepare("SELECT * FROM tb_caro WHERE id_caro = '$id'");
    $b ->execute();
    $result = $b->fetch(PDO::FETCH_ASSOC);
?>
<form method="post" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?=$result['id_caro']?>">

    <div class="mt-3">
        <span class="label label-danger">Gambar</span>
        <input class="form-control" type="file" name="gbr" value="<?=$result['gambar']?>">
    </div>

    <div class="mt-3">
        <button name="btn" type="submit" class="btn btn-warning btn-sm">Update</button>
    </div>
</form>

<?php
    if(isset($_POST['btn'])) {
        $path = '../gbrproject/';
        $idb = $_POST['id'];
        $gbr = $_FILES['gbr']['name'];
        move_uploaded_file($_FILES['gbr']['tmp_name'],$path.$gbr);
        $query = $conn->prepare("UPDATE tb_caro SET  gambar=:gbr WHERE id_caro=:id");
        $query->bindParam(':id', $idb);
        $query->bindParam(':gbr', $gbr);
        if($query->execute()){
            header('location:?page=caro'); 
        } else{
            echo "gagal";
        }
    } 
?>