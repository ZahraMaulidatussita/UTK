    <!-- Dashboard Heading -->
    <div class="mt-4">
      <h2 class="mb-4">Kelola Product</h2>
      <a href="?page=addpro" class="btn btn-primary mb-3"><i class="fas fa-plus"></i>Tambah Product</a>

      <!-- Table -->
      <div class="table-responsive">
        <table class="table table-striped table-bordered">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nama Product</th>
              <th>Dekripsi</th>
              <th>Harga</th>
              <th>Gambar</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>

          <style>
            td:nth-child(2),
            td:nth-child(4),
            td:nth-child(6)
            {
              white-space: nowrap;
            }
          </style>
            <?php
                $no = 1;
                $sqlOut = $conn->prepare("SELECT*FROM tb_product");
                $sqlOut->execute();
                foreach ($sqlOut as $row) {
                  ?>
            <tr>
              <td><?=$no++?></td>
              <td><?=$row['nama_product']?></td>
              <td><?=$row['deskripsi']?></td>
              <td>Rp <?= number_format($row['harga'], 0, ',', '.')?></td>
              <td>
              <?php if ($row['gambar']) : ?>
                <img src="../gbrproject/<?= $row['gambar']?>" width="80">
              <?php else : ?>
                <span>Tidak ada</span>
              <?php endif; ?>

              <td>
                <a href="?page=edpro&idpro=<?=$row['id_product']?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Edit</a>
                <a href="?page=delpro&idpro=<?=$row['id_product']?>" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Delete</a>
              </td>
              </td>
            </tr>
                  <?php
                  
                }
            ?>
            
          </tbody>
        </table>
      </div>
    </div>