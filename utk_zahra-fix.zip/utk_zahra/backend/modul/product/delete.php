<?php
    $id = $_GET['idpro'];
    $b = $conn->prepare("DELETE FROM tb_product WHERE id_product = '$id'");
    if($b->execute()){
    header('location:?page=datapro');
    }
?>