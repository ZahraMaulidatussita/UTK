<div class="mt-4">
      <h2 class="mb-4">Tambah Data Product</h2>
<form action="" method="POST" enctype="multipart/form-data">

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Nama Product</label>
  <input type="text" class="form-control" name="nm">
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Deskripsi</label>
  <input type="text" class="form-control" name="dsk">
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Harga</label>
  <input type="text" class="form-control" name="hrg">
</div>

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Gambar</label>
  <input type="file" class="form-control" name="gbr">
</div>


<div class="mb-3">
    <button type="submit" class="btn btn-success" name="btn">Input Data</button>
</div>
</form>
<?php
if(isset($_POST['btn'])){
    $nm = $_POST['nm'];
    $dsk = $_POST['dsk'];
    $gbr = $_FILES['gbr']['name'];
    $hrg = $_POST['hrg'];
    $path = '../gbrproject/';
    move_uploaded_file($_FILES['gbr']['tmp_name'],$path.$gbr);
    $sqlinput = $conn->prepare('INSERT INTO tb_product(nama_product,deskripsi,harga,gambar)VALUES(:nama_product,:deskripsi,:harga,:gambar)');
    $sqlinput->bindParam(':nama_product', $nm);
    $sqlinput->bindParam(':deskripsi', $dsk);
    $sqlinput->bindParam(':harga', $hrg);
    $sqlinput->bindParam(':gambar', $gbr);
    if($sqlinput->execute()){
      header('location:?page=datapro');
      exit;
    }else {
      echo "Gagal menambahkan data :" . $sqlinput->errorInfo()[2];
        }
      }
?>
</div>