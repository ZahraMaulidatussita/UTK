<div class="mt-4">
    <h2 class="mb-4">Edit Product</h2>
</div>

<?php
    $id = $_GET['idpro'];
    $b = $conn->prepare("SELECT * FROM tb_product WHERE id_product = '$id'");
    $b ->execute();
    $result = $b->fetch(PDO::FETCH_ASSOC);
   
?>
<form method="post" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?=$result['id_product']?>">

    <div class="mt-3">
        <span class="label label-danger">Nama Product</span>
        <input class="form-control" type="text" name="nm" value="<?=$result['nama_product']?>">
    </div>

    <div class="mt-3">
        <span class="label label-danger">Deskripsi</span>
        <input class="form-control" type="text" name="dsk" value="<?=$result['deskripsi']?>">
    </div>

    <div class="mt-3">
        <span class="label label-danger">Harga</span>
        <input class="form-control" type="text" name="hrg" value="<?=$result['harga']?>">
    </div>

    <div class="mt-3">
        <span class="label label-danger">Gambar</span>
        <input class="form-control" type="file" name="gbr">
    </div>
    <div class="mt-3">
        <button name="btn" type="submit" class="btn btn-warning btn-sm">Update</button>
    </div>
</form>

<?php
    if(isset($_POST['btn'])) {
        $path = '../gbrproject/';
        $idp = $_POST['id'];
        $nm = $_POST['nm'];
        $dsk = $_POST['dsk'];
        $hrg = $_POST['hrg'];
        
        $gbr = $_FILES['gbr']['name'];
        if(!empty($gbr)) {
            move_uploaded_file($_FILES['gbr']['tmp_name'], $path . $gbr);
        } else {
            $gbr = $result['gambar'];
        }

        $query = $conn->prepare("UPDATE tb_product SET nama_product=:namapro, deskripsi=:deskrip, harga=:hrga, gambar=:gmbr WHERE id_product=:id");
        $query->bindParam(':id', $idp);
        $query->bindParam(':namapro', $nm);
        $query->bindParam(':deskrip', $dsk);
        $query->bindParam(':hrga', $hrg);
        $query->bindParam(':gmbr', $gbr);
        if($query->execute()){
            header('location:?page=datapro'); 
        } else{
            echo "Gagal Update Produk";
        }
    } 
?>