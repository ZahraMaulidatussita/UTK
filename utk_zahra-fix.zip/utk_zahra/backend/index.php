<?php 
        include"../lib/koneksi.php";
        session_start();
        if(!isset($_SESSION['admin'])){
          header("location: login_admin.php");
          exit;
        }

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="asset/css/style.css">
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
 
</head>
<body>

<?php 
        include"modul/sidebar.php";
  ?>
 

  <!-- Main Content -->
  <div class="content">

  <?php 
    $page = isset($_GET['page'])?$_GET['page']:"";
  switch ($page) {
        case 'cont';
          include "modul/content.php";
          break;

        case 'addcaro':
          include "modul/carousel/add.php";
          break;

        case 'caro':
          include "modul/carousel/data.php";
          break;

        case 'delro':
          include "modul/carousel/delete.php";
          break;

        case 'edit':
          include "modul/carousel/edit.php";
          break;

        case 'datapro':
          include "modul/product/data.php";
          break;

        case 'addpro':
          include "modul/product/add.php";
          break;

        case 'delpro':
          include "modul/product/delete.php";
          break;

        case 'edpro':
          include "modul/product/edit.php";
          break;

        case 'pesan':
          include "modul/pesanan.php";
          break;

          case 'feedback':
            include "modul/feedback.php";
            break;

              case 'logout':
                include "logout_admin.php";
                break;
                
              case 'login':
                include "login_admin.php";
                break;
            
  
    default:
    case 'cont';
    include "modul/content.php";
    break;

  }
        
    ?>

  </div>

  <!-- Footer -->
  <footer class="footer">
    &copy; 2025 Admin Dashboard - All Rights Reserved
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
