-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2025 at 08:51 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_jco`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin12');

-- --------------------------------------------------------

--
-- Table structure for table `tb_caro`
--

CREATE TABLE `tb_caro` (
  `id_caro` int(11) NOT NULL,
  `gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_caro`
--

INSERT INTO `tb_caro` (`id_caro`, `gambar`) VALUES
(2, '1.webp'),
(7, 'caro.webp');

-- --------------------------------------------------------

--
-- Table structure for table `tb_checkout`
--

CREATE TABLE `tb_checkout` (
  `id_checkout` int(11) NOT NULL,
  `nama_penerima` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `metode_pembayaran` enum('transfer','cod','ewallet') NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL,
  `tanggal_checkout` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_checkout`
--

INSERT INTO `tb_checkout` (`id_checkout`, `nama_penerima`, `email`, `alamat`, `metode_pembayaran`, `nama_produk`, `harga`, `tanggal_checkout`) VALUES
(1, 'ssss', 'ddd@gmail.com', 'aaaa', 'cod', 'ALCAPONE', 10000, '2025-05-12 16:16:32'),
(2, 'joko', 'joko12@gmail.com', 'gg mangga', 'cod', 'ALCAPONE', 10000, '2025-05-12 16:26:23'),
(3, 'miranti', 'mirandi@gmail.com', 'gang cermai rt 019 / rw 098', 'cod', 'AVOCADO', 10000, '2025-05-12 18:16:15'),
(4, 'saiman', 'saiman@gmail.com', 'gg buntu', 'transfer', 'CAVIAR STAWBERRY', 10000, '2025-05-12 18:18:31'),
(5, 'yaya', 'yaya@gmail.com', 'rt 099 rw 888', 'cod', 'BERRY SPEARS', 10000, '2025-05-12 18:32:52'),
(6, 'joko', 'joko12@gmail.com', 'gg batu', 'cod', 'ALCAPONE', 10000, '2025-05-14 07:50:05'),
(7, 'maya', 'maya@gmail.com', 'rt 009 rw 888', 'cod', 'AVOCADO', 10000, '2025-05-14 12:52:51'),
(8, 'saroh', 'saroh@gmail.com', 'Gg sirsak, Rt 009/ Rw 009', 'cod', 'COCOLOCO', 15000, '2025-05-14 23:06:52'),
(9, 'miranti', 'miranti@gmail.com', 'Jalan Srikaya, Rt 009/ Rw 007', 'cod', 'MEISISIPI', 14000, '2025-05-15 11:24:52'),
(10, 'santi', 'santi@gmail.com', 'Gg Buntu', 'cod', 'AVOCADO', 10000, '2025-05-16 10:47:41'),
(11, 'Mira', 'miranti@gmail.com', 'Jalan Ampel', 'cod', 'AVOCADO', 10000, '2025-05-16 10:58:35');

-- --------------------------------------------------------

--
-- Table structure for table `tb_feedback`
--

CREATE TABLE `tb_feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_feedback`
--

INSERT INTO `tb_feedback` (`id`, `name`, `email`, `message`) VALUES
(1, 'yani', 'yani@gmail.com', 'sangat lezat'),
(2, 'marni', 'marni@gmail.com', 'delicious');

-- --------------------------------------------------------

--
-- Table structure for table `tb_product`
--

CREATE TABLE `tb_product` (
  `id_product` int(11) NOT NULL,
  `nama_product` varchar(255) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `harga` int(11) NOT NULL,
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_product`
--

INSERT INTO `tb_product` (`id_product`, `nama_product`, `deskripsi`, `harga`, `gambar`) VALUES
(7, 'CAVIAR STAWBERRY', 'Donut dipped in strawberry milk chocolate and sprinkled with dark chocolate coated crisps.', 15000, 'CAVIAR.webp'),
(10, 'AVOCADO', 'Donut filled with avocado cream, dipped in avocado chocolate, and garnished with dark chocolate flakes.', 10000, 'cado.webp'),
(11, 'BERRY SPEARS', 'Donut filled with whipped cream cheese, dipped in strawberry jam, and garnished with white chocolate flakes.', 10000, 'beryy.webp'),
(12, 'ALCAPONE', 'Donut dipped in white chocolate and topped with sliced toasted almonds.', 10000, 'all.webp'),
(13, 'MEISISIPI', 'Donut dipped in dark chocolate ganache and topped with chocolate sprinkles.', 14000, 'mei.webp'),
(14, 'CAVIAR CHOCOLATE', 'Donut dipped in hazelnut chocolate and sprinkled with dark chocolate coated crisps.', 10000, 'cav.webp'),
(15, 'HEAVEN BERRY', 'Donut filled with strawberry cream filling, dipped in strawberry milk chocolate, and garnished with white chocolate.', 10000, 'heaven.webp'),
(16, 'WHY NUT', 'Donut filled with peanut butter cream, dipped in white chocolate, and garnished with dark chocolate.', 10000, 'why.webp'),
(17, 'BLUE BERRYMORE', 'Donut filled with whipped cream cheese, dipped in blueberry jam, and garnished with white chocolate flakes.', 15000, 'blu.webp'),
(18, 'TIRAMISU', 'Donut filled with tiramisu cream, dipped in tiramisu chocolate, and sprinkled with chocolate powder.', 10000, 'tiramisu.webp'),
(19, 'OREOLOGY', 'Donut dipped in white chocolate, topped with cookie crumbs, and drizzled with white chocolate.', 10000, 'oreo.webp'),
(20, 'COPA BANANA', 'Donut filled with banana custard cream, dipped in dark chocolate, and garnished with a dollop of banana custard cream.', 8000, 'copa.webp'),
(21, 'MR GREEN TEA', 'Donut dipped in green tea chocolate and topped with crushed toasted almonds.', 12000, 'GR.webp'),
(22, 'COCOLOCO', 'Donut filled with dark chocolate ganache and dipped in dark chocolate.', 15000, 'COCO.webp'),
(23, 'CRUNCHY CRUNCHY', 'Donut dipped in milk chocolate and topped with chocolate cornflakes.', 20000, 'crunchy.webp');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `nama_user`, `email`, `password`) VALUES
(1, 'miranti', 'miranti@gmail.com', 'miraa12'),
(2, 'santi', 'santi@gmail.com', 'santi12'),
(3, 'nunu', 'nunu@gmail.com', 'nunu123'),
(5, 'andi', 'andi@gmail.com', '$2y$10$jnB/JPVtEnpDcfp7IixSUeFQwbif3O7bWq2UYykqfBRRSGmIe4Eiu'),
(6, 'dian', 'dian@gmail.com', 'dian123'),
(7, 'kaila', 'kaila@gmail.com', 'kaila12'),
(8, 'sinta', 'sinta@gmail.com', 'sinta12'),
(9, 'sri', 'sri@gmail.com', 'sri123'),
(10, 'ade', 'ade@gmail.com', 'ade123'),
(11, 'ratu', 'ratu@gmail.com', 'ratu123'),
(12, 'aluna', 'aluna@gmail.com', '12345'),
(13, 'yuyun', 'yuyun@gmail.com', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_caro`
--
ALTER TABLE `tb_caro`
  ADD PRIMARY KEY (`id_caro`);

--
-- Indexes for table `tb_checkout`
--
ALTER TABLE `tb_checkout`
  ADD PRIMARY KEY (`id_checkout`);

--
-- Indexes for table `tb_feedback`
--
ALTER TABLE `tb_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_product`
--
ALTER TABLE `tb_product`
  ADD PRIMARY KEY (`id_product`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_caro`
--
ALTER TABLE `tb_caro`
  MODIFY `id_caro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tb_checkout`
--
ALTER TABLE `tb_checkout`
  MODIFY `id_checkout` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tb_feedback`
--
ALTER TABLE `tb_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_product`
--
ALTER TABLE `tb_product`
  MODIFY `id_product` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
